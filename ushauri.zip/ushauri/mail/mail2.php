<?php
if (function_exists('mail')) {
    echo "mail() function is enabled.";
} else {
    echo "mail() function is disabled.";
}
?>
